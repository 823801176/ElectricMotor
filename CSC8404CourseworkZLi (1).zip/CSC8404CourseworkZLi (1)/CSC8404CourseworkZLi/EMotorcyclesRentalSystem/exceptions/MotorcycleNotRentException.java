package EMotorcyclesRentalSystem.exceptions;

public class MotorcycleNotRentException extends Exception{
    public MotorcycleNotRentException(String message) {
        super(message);
    }
}
